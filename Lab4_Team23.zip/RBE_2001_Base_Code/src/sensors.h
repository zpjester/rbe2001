#include <Arduino.h>
// #include "IRdecoder.h"
class RomiSensors{
    
    public:
    // IRDecoder(void) : decoder(14) {
    // }
    void sensorsInit(void);
/*/
};
/*/  
    String getIRDirectionFromCode(int32_t code, bool compass);
    String getIRDirection(bool compass);   
    // RomiSensors();  
};