class buzzer{
    int pin;



    buzzer(int buzzerPin){
        pin = buzzerPin;
    }
};