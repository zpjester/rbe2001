/*#include <Romi.cpp>//This should handle all required includes

//Replace all references to FILENAME with the current file name.
class FILENAME{
    private:
Romi robot = Romi();//Create robot object


void setup(){
//Put your setup code here, to run once.
}
void loop(){
//Put your loop code here, to run repeatedly.
}


public:
FILENAME(){
    setup();
    while(true){
        loop();
    }
}
};
*/