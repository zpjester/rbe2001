#include <utils.h>
int sign(float x){
    return abs(x) / x;
}