//
#include <Romi.cpp>
#include <blueMotor.h>
#include <servo32u4.h>
#include <fourBar.h>
Romi robot = Romi();
fourBar lift;
Servo32U4 gripper = Servo32U4();
// IRDecoder decoder(14);
enum driveType{initialize, driving, turning};
int driveState;
void setup(){
//Put your setup code here, to run once.
Serial.begin(9600);
// robot.robotFastInit();
gripper.Attach();
gripper.Init();
lift.setup();
lift.reset();
driveState = initialize;
lift.liftMotor.setObject(0);
lift.goDown();
}
void loop(){
//Put your loop code here, to run repeatedly.

lift.liftMotor.testDBands(0);
while(true){}
/*
lift.goToAngle(3.425);
gripper.Write(1100);
Serial.println("moving up");
int cycles = 0;
long startTime = millis();
while(true){
    delay (10);
    cycles++;
    if(cycles == 10){
        lift.runArm();
        cycles = 0;
        Serial.print(lift.liftMotor.getPosition());
        Serial.print(",");
        Serial.print(lift.liftMotor.targetPosition);
        Serial.print(",");
        Serial.print(lift.liftMotor.currEffort);
        Serial.print(",");
        Serial.print(lift.liftMotor.currEffortCorrected);
        Serial.print(",");
        Serial.print(lift.liftMotor.getVelocity());
        Serial.print(",");
        Serial.println(millis() - startTime);
    }


    // Serial.println(lift.getAngle());
}
/*
Serial.println("moving down");
lift.goToAngle(0);
gripper.Write(1700);
while (!lift.runArm()){
    delay (10);
    // Serial.println(lift.getAngle());
}
delay(500);*/


};


