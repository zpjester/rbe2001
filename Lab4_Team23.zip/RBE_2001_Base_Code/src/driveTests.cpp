/*//Template code
#include <Romi.cpp>
Romi robot = Romi();

void setup(){
    delay(5000);  
  robot.drive.driveTest("FORWARDS", 1);
  delay(1000);
  robot.drive.driveTest("BACKWARDS", 1);
  delay(1000);
  robot.drive.driveTest("LEFT", 1);
  delay(1000);
  robot.drive.driveTest("RIGHT", 1);
}

void loop(){

}

*/