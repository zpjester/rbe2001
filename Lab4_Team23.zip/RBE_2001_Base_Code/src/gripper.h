#include <servo32u4.h>
class gripper{
    private:
    Servo32U4 servo;
    float currAngle;//Current angle
    float targetAngle;//Set angle
    float minAnglePot;//Potentiometer reading at 0 deg
    float maxAnglePot;//Potentiometer reading 1y 180 deg

    float openAngle;//Open position
    float closedAngle;//Closed position
    float openVal = 1700;
    float closedVal = 1100;
    public:
    void init();
    void setAngle(float angle);
    void open();
    void closed();
    float getAngle();
    bool runServo();
};